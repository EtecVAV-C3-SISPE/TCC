from flask import Blueprint, render_template
from routes.pais import pais_route
from routes.professores import professores_route
from database.database import db
from database.models.pais import Pais, Professores

# Criamos o blueprint principal aqui mesmo
main_route = Blueprint("main", __name__)

# ====== ROTAS PRINCIPAIS ======
@main_route.route("/")
def home():
    return render_template("2-dashboard.html")

@main_route.route("/login")
def login():
    return render_template("1-login.html")

@main_route.route("/noticias")
def noticias():
    return render_template("3-noticias.html")

@main_route.route("/calendario")
def calendario():
    return render_template("4-calendario.html")

# ====== PASSEIOS ======
@main_route.route("/passeios")
def passeios():
    return render_template("4-passeios.html")

@main_route.route("/passeio_detalhes")
def passeio_detalhes():
    return render_template("4-passeio_detalhes.html")

@main_route.route("/passeio_anexos")
def passeio_anexos():
    return render_template("4-passeio_anexos.html")

# ====== DIÁRIO / FALTAS ======
@main_route.route("/diario")
def diario():
    return render_template("5-diario.html")

@main_route.route("/faltas")
def faltas():
    return render_template("5-faltas.html")

# ====== FORMULÁRIOS ======
@main_route.route("/form_pais")
def form_pais():
    return render_template("form_pais.html")

@main_route.route("/form_professores")
def form_professores():
    return render_template("form_professores.html")


def configure_all(app):
    configure_routes(app)
    configure_db()


def configure_routes(app):
    app.register_blueprint(pais_route, url_prefix='/pais')
    app.register_blueprint(professores_route, url_prefix='/professores')
    app.register_blueprint(main_route)  # 👈 registra as rotas criadas aqui


def configure_db():
    db.connect()
    db.create_tables([Pais])
    db.create_tables([Professores])
