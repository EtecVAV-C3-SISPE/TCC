from peewee import SqliteDatabase

db = SqliteDatabase('customermanager.db')